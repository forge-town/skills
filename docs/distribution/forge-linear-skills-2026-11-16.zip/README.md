# Linear Skills · 2026-11-16

本包包含八个 forge--linear--* Skill，使用统一字段契约 v18。

将 skills/ 内八个完整目录复制到目标应用技能目录，保持同级。采用独立实体目录；已有版本先备份再替换，不需要个人安装路径或软链接。

个人入口 create-linear-issues 对应 forge--linear--create-issues；backfill-linear-issues 对应 forge--linear--backfill-issues。plan-linear-cycle 不包含在此包。

用浏览器打开 forge--linear--show-issue-form/assets/issue-form.html；保留 assets/examples/，Header 中可以查看 Todo List 与类幸存者两个 Feature。

生成页面和正文需要 Node.js 24+；补录计点需要 Python 3。示意命令需调整 SKILL_ROOT / PROJECT_ROOT：

```sh
node --experimental-strip-types SKILL_ROOT/forge--linear--show-issue-form/scripts/show-issue-form.ts --output PROJECT_ROOT/docs/issue-form.html
node SKILL_ROOT/forge--linear--create-issues/scripts/assemble-issue.mjs --input PROJECT_ROOT/docs/form.json --output PROJECT_ROOT/docs/issue.md --linear-output PROJECT_ROOT/docs/linear.json
node SKILL_ROOT/forge--linear--create-issues/scripts/validate-issue-body.mjs --form PROJECT_ROOT/docs/form.json PROJECT_ROOT/docs/issue.md
```

创建和规格 review 共用表单 JSON 及生成器，不手改生成的正文。未知字段拒绝，缺项以待补草稿交付。真实 Linear 写入需要使用者的自装 MCP 和授权，本包不含账号凭据。

独立 HTML 评审报告还需 lv-editorial-pdf 与其 Python 依赖；逐 Task 视频、配音和形式化验证等额外产物按对应 reference 准备依赖。附带源码测试用于原仓库开发检查，本 ZIP 不是完整的仓库测试工程。原型、示例和本地生成不代表真实产品验收通过。

文件校验见 SHA256SUMS。LICENSE 与随包 third_party 版权声明一并保留。
